echo "downloading inception weights"
curl "http://kaishengtai.github.io/static/projects/neuralart/inception_caffe.th" -o models/inception_caffe.th
echo "downloading vgg weights"
curl "http://kaishengtai.github.io/static/projects/neuralart/vgg_normalized.th" -o models/vgg_normalized.th
