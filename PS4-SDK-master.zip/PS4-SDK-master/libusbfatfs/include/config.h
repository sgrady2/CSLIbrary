#ifndef __CONFIG_H__
#define __CONFIG_H__

// #define DEBUG_FLASH_DRIVE				1
// #define DEBUG_DISKIO						1
// #define DEBUG_MASS_STORE_COMMANDS		1

// USB Flash Drive information
#define USB_DEVICE_VID 						0x0781
#define USB_DEVICE_PID						0x5151

#endif