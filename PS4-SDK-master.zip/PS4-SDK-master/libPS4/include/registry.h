#pragma once

int registryCommand(int command);
