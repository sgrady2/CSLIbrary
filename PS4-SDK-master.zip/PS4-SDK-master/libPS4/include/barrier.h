#pragma once

int mutexInit(const char *name, unsigned int attributes);
int mutexDestroy(int mutex);
