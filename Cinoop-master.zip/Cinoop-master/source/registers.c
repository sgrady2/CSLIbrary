#include "registers.h"

struct registers registers;
